<?php 
class DATABASE_CONFIG { 
	// public $default = array(
		// 'datasource' => 'Database/Mysql',
		// 'port' => 'n',
		// 'login' => '',
		// 'host' => '',
		// 'persistent' => false,
		// 'database' => '',
		// 'password' => '',
		// 'prefix' => '',
		// 'encoding' => '',
	// );

}
